import './App.css'
import Desktop from "./pages/Desktop"
import Tablet from "./pages/Tablet"
import Mobile from "./pages/Mobile"
import React, { useState, useEffect } from 'react';

const App = () => {
  const [windowSize, setWindowSize] = useState(window.innerWidth);

  const handleResize = () => {
    setWindowSize(window.innerWidth);
  };

  useEffect(() => {
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  return(
    <div>
      {windowSize > 1300 ? <Desktop/> : windowSize > 748 ? <Tablet/> : <Mobile/>}
    </div>
  )
}

export default App
