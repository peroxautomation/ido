/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        "neutral-900": "#0b0b0b",
        "neutral-800": "#1b1b1b",
        "neutral-600": "#424242",
        "primary-500": "#cc0f3c",
        "danger-500": "#cc240e",
        "neutral-100": "#fff",
        "white-8": "rgba(255, 255, 255, 0.08)",
        "white-16": "rgba(255, 255, 255, 0.16)",
        "white-40": "rgba(255, 255, 255, 0.4)",
        "neutral-200": "#e9e9e9",
        gray: "rgba(0, 0, 0, 0.7)",
        black: "rgb(0 0 0)",
        white: "#fff",
      },
      fontFamily: {
        "body-regular": "Nunito",
        "sf-pro-text": "'SF Pro Text'",
        "button-1-semibold": "Nunito",
      },
    },
    fontSize: {
      base: "16px",
      sm: "14px",
      "21xl": "40px",
      "13xl": "32px",
      "5xl": "24px",
      xl: "20px",
      inherit: "inherit",
    },
  },
}

