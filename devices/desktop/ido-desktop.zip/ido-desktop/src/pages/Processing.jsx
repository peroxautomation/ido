const Processing = () => {
  return (
    <div className="w-full relative bg-neutral-900 h-screen overflow-hidden text-center text-21xl text-white font-button-1-semibold">
      <img
        className="absolute top-[calc(50%_-_71.5px)] left-[calc(50%_-_25px)] w-14 h-14 overflow-hidden"
        alt=""
        src="/hugeiconinterfacebulkloading-01.svg"
      />
      <div className="absolute top-[calc(50%_+_24.5px)] left-[calc(50%_-_270px)] w-[541px] flex flex-row items-center justify-center">
        <div className="flex-1 relative leading-[48px]">Processing</div>
      </div>
    </div>
  );
};

export default Processing;
