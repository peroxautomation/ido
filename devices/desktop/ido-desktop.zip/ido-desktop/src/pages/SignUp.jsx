import SignUpDropdowns from "../components/SignUpDropdowns";
import SignUpMain from "../components/SignUpMain";

const SignUp = () => {

  
  return (
    <div className="absolute w-full h-full bg-black text-center text-21xl text-neutral-100 font-h2-regular">
      
      {/* Going to need a onclick event */}
      {/* <SignUpDropdowns/> */}
      <SignUpMain />
    </div>
  );
};

export default SignUp;
