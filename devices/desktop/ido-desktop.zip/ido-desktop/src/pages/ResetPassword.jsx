import ResetInputEmail from "../components/ResetInputEmail";
import ResetNewPassword from "../components/ResetNewPassword";

const ResetPassword = () => {
  return (
    <div className="absolute w-full h-full bg-black text-center text-21xl text-neutral-100 font-h2-regular">
      <ResetInputEmail />
      {/* <ResetNewPassword/> */}
      <div className="absolute top-[40px] left-[48px] w-[1344px] flex flex-row items-start justify-between py-4 px-0 box-border">
        <button className="cursor-pointer [border:none] p-0 bg-[transparent] w-10 relative h-10 overflow-hidden shrink-0">
          <img
            className="absolute h-[48%] w-[23%] top-[26%] right-[38.5%] bottom-[26%] left-[38.5%] max-w-full overflow-hidden max-h-full"
            alt=""
            src="/direction-left.svg"
          />
        </button>
        
        <img
          className="w-10 relative h-10 overflow-hidden shrink-0 opacity-[0]"
          alt=""
        />
      </div>
      <div className="self-stretch flex flex-row items-center justify-center py-40 px-2 text-21xl">
        <div className="relative leading-[48px]">Reset Password</div>
      </div>
    </div>
  );
};

export default ResetPassword;
