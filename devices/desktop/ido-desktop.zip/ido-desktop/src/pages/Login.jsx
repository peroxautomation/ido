import LogInMain from "../components/LogInMain";

const Login = () => {
  return (
    <div className="absolute w-full h-full bg-black text-center text-21xl text-neutral-100 font-h2-regular">
      <LogInMain />
      <button className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[56px] left-[48px] w-[9.2px] h-[19.2px]">
        <img
          className="absolute top-[0px] left-[0px] w-[9.2px] h-[19.2px] object-contain"
          alt=""
          src="/vector-175-stroke.svg"
        />
      </button>
    </div>
  );
};

export default Login;
