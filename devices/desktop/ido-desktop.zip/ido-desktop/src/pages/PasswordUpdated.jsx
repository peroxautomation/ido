const PasswordUpdated = () => {
  return (
    <div className="w-full relative bg-neutral-900 h-screen overflow-hidden text-center text-21xl text-white font-button-1-semibold">
      <img
        className="absolute top-[calc(50%_-_120px)] left-[calc(50%_-_27px)] w-14 h-14 overflow-hidden"
        alt=""
        src="/hugeiconinterfaceoutlinecheckcircle.svg"
      />
      <div className="absolute top-[calc(50%_-_42px)] left-[calc(50%_-_270px)] w-[541px] flex flex-row items-center justify-center">
        <div className="flex-1 relative leading-[48px]">
          Your password has been successfully updated
        </div>
      </div>
      <button className="cursor-pointer [border:none] py-2.5 px-2 bg-primary-500 absolute top-[calc(50%_+_94px)] left-[calc(50%_-_170px)] rounded-xl w-[340px] flex flex-row items-center justify-center box-border gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
          alt=""
          src="/hugeiconinterfacesolidplus.svg"
        />
        <div className="relative text-base leading-[24px] font-semibold font-button-1-semibold text-white text-center">
          Log in
        </div>
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
          alt=""
          src="/hugeiconinterfacesolidplus.svg"
        />
      </button>
    </div>
  );
};

export default PasswordUpdated;
