const SignUpQuestion = () => {
  return (
    <div className="absolute w-full h-full bg-black">
      <button className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[56px] left-[48px] w-[9.2px] h-[19.2px]">
        <img
          className="absolute top-[0px] left-[0px] w-[9.2px] h-[19.2px] object-contain"
          alt=""
          src="/vector-175-stroke.svg"
        />
      </button>

      <div className="absolute top-[66px] left-[calc(50%_-_170px)] w-[340px] h-[789px] overflow-y-auto flex flex-col items-start justify-start gap-[40px]">
        <div className="self-stretch h-12 shrink-0 flex flex-row items-center justify-center py-0 px-2 box-border">
          <div className="relative leading-[48px]">Questions</div>
        </div>
      </div>
    </div>
  );
};

export default SignUpQuestion;
