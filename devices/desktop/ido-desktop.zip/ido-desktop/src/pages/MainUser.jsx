import TrendingNowSection from "../components/TrendingNowSection";
import RecentlyAddedSection from "../components/RecentlyAddedSection";
import GenresSection  from "../components/GenresSection";
import UserHeader from "../components/UserHeader";
import UserNav from "../components/UserNav";
import DropdownGenre from "../components/DropdownGenre";
import GroupCards from "../components/GroupCards";
import SearchMain from "../components/SearchMain";
import HistoryMain from "../components/HistoryMain";
import LikedVideosMain from "../components/LikedVideosMain";
      
const MainUser = () => {

  return (
    
    <div className="absolute w-full h-full bg-black text-white">
      <UserNav/>
      <UserHeader/>

      {/* onclickHome */}
      {/* <div className="absolute h-[calc(100%_-_368px)] w-[calc(100%_-_360px)] top-[352px] right-[48px] bottom-[16px] left-[312px] flex flex-col items-start justify-start gap-[20px] overflow-hidden ">
        <TrendingNowSection />
        <RecentlyAddedSection />
      </div>
      <GenresSection/> */}

      {/* onclickSearch */}
      {/* <SearchMain/> */}

      {/* onclickHistory */}
      {/* <HistoryMain/> */}

      {/* onclickLiked */}
      {/* <LikedVideosMain/> */}
    </div>
  );
};

export default MainUser;
