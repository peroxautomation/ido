import { useState } from 'react'
import './App.css'
import MainGuest from './pages/MainGuest'
import SignUp from './pages/SignUp'
import ResetPassword from './pages/ResetPassword'
import Login from './pages/Login'
import SucessfullyStartedPlan from './pages/SucessfullyStartedPlan'
import PasswordUpdated from './pages/PasswordUpdated'
import Processing from './pages/Processing'
import SignUpQuestion from './pages/SignUpQuestion'
import MainUser from './pages/MainUser'

function App() {
  return (
    <div>
      {/* <MainGuest/> */}
      {/* <SignUp/> */}
      {/* <ResetPassword/> */}
      {/* <Login/> */}
      {/* <SucessfullyStartedPlan/> */}
      {/* <PasswordUpdated/> */}
      {/* <Processing/> */}
      <MainUser/>


      {/* Not working */}
      {/* <SignUpQuestion/> */}

    </div>
  )
}

export default App
