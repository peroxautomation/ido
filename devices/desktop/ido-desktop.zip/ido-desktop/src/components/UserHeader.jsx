import LOGO from "./LOGO";
import SearchBar from "./SearchBar";
import CreateChallengeBtn from "./CreateChallengeBtn";

const UserHeader = () => {
  return (
    <header className="absolute w-full top-[0px] right-[0px] left-[0px] shadow-[0px_4px_20px_rgba(0,_0,_0,_0.25)] bg-neutral-800 flex flex-row items-center justify-between py-8 px-12 box-border text-center text-13xl text-neutral-100 font-body-regular">
      <LOGO />
      <div className="flex flex-row items-center justify-start gap-[24px]">
        <SearchBar />
        <CreateChallengeBtn />
        <a className="[text-decoration:none] flex flex-row items-center justify-start text-xl text-[inherit]">
            <div className="flex flex-row items-center justify-start gap-[8px]">
              <img
                className="w-11 relative rounded-[50%] h-11 object-cover"
                alt=""
                src="/ellipse-1254@2x.png"
              />
              <div className="relative leading-[28px] font-semibold">
                Username
              </div>
            </div>
          </a>
      </div>
    </header>
  );
};

export default UserHeader;