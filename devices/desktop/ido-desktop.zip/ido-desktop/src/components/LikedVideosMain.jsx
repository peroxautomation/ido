import React from 'react'
import GroupCards from './GroupCards'

const LikedVideosMain = () => {
  return (
    <div>
        <div className="absolute top-[148px] left-[312px] w-[1080px] flex flex-row items-start justify-start py-4 px-0 box-border gap-[16px] text-left">
        <button>
        <img
          className="w-10 relative h-10 overflow-hidden shrink-0"
          alt=""
          src="/hugeiconarrowsbulkdirectionleft-01.svg"
        />
        </button>
        <div className="relative leading-[40px] font-semibold text-13xl">Liked Videos</div>
      </div>
      <GroupCards/>
      
    </div>
  )
}

export default LikedVideosMain
