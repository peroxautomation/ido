const Card = () => {
  return (
    <div className="flex-1 relative rounded-2xl h-[252px] overflow-hidden bg-[url('/public/card@3x.png')] bg-cover bg-no-repeat bg-[top] text-center text-base text-neutral-100 font">
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] rounded-t-none rounded-b-2xl [background:linear-gradient(180deg,_rgba(255,_255,_255,_0),_rgba(0,_0,_0,_0.8))] h-[73px]" />
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] flex flex-row items-center justify-center p-4 box-border gap-[24px]">
        <div className="flex flex-row items-start justify-start gap-[8px]">
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] w-6 relative h-6">
            <img
              className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] max-w-full overflow-hidden max-h-full"
              alt=""
              src="/heart-icons.svg"
            />
          </button>
          <div className="relative tracking-[-0.41px] leading-[24px]">783</div>
        </div>
        <div className="flex flex-row items-start justify-end gap-[8px]">
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconinterfaceoutlineeye.svg"
          />
          <div className="relative tracking-[-0.41px] leading-[24px]">1043</div>
        </div>
      </div>
      <button className="cursor-pointer [border:none] p-2 bg-white-40 absolute top-[8px] right-[8px] rounded-xl flex flex-row items-start justify-end">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 object-cover"
          alt=""
          src="/hugeiconinterfacesolidmorehorizontal@2x.png"
        />
      </button>
    </div>
  );
};

export default Card;
