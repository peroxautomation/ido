import Dropdown from "./Dropdown";

const SignUpDropdowns = () => {
  return (
    <div>
      <div className="absolute top-[291px] left-[calc(50%_-_160px)] flex flex-col items-start justify-start gap-[16px] text-left text-base text-neutral-100 font-h2-regular">
      <div className="w-80 flex flex-row items-center justify-center py-0 px-2 box-border text-center text-21xl">
        <div className="relative leading-[48px]">Sign up</div>
      </div>
        <Dropdown dropdown="Country" />
        <Dropdown dropdown="State" />
        <Dropdown dropdown="City" />
        <button className="cursor-pointer [border:none] py-2.5 px-2 bg-primary-500 self-stretch rounded-xl flex flex-row items-center justify-center gap-[8px]">
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconinterfacesolidplus1.svg"
          />
          <div className="relative text-base leading-[24px] font-semibold font-h2-regular text-neutral-100 text-center">
            Next
          </div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconinterfacesolidplus1.svg"
          />
        </button>
      </div>
      
    </div>
  );
};

export default SignUpDropdowns;
