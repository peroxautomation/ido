import GenreCard from "./GenreCard";

const GenresSection = () => {
  return (

    <section className="absolute top-[148px] right-[48px] left-[312px] h-[200px] overflow-x-auto flex flex-row items-start justify-start overflow-y-hidden text-center text-base text-neutral-100 font-button-2-semibold">
      <div className="w-[1080px] relative h-[220px] shrink-0 ">
        <GenreCard genreName="Ballroom" />
        <GenreCard cardLeft="0px" genreName="Contemporary" genreNameLeft="16px" />
        <GenreCard cardLeft="220px" genreName="Cultural" genreNameLeft="38px" />
        <GenreCard cardLeft="440px" genreName="Hip Hop" genreNameLeft="37px" />
        <GenreCard cardLeft="660px" genreName="Jazz" genreNameLeft="53px" />
        <GenreCard cardLeft="880px" genreName="Tap" genreNameLeft="54px" />
        <GenreCard cardLeft="1100px" genreName="Folk" genreNameLeft="52px" />
        <GenreCard cardLeft="1320px" genreName="Modern" genreNameLeft="39px" />
      </div>
    </section>
  );
};

export default GenresSection;
