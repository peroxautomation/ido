import NavBtn from "./NavBtn";
import UpgradeBtn from "./UpgradeBtn";

const UserNav = () => {
  return (
    <nav className="m-0 absolute h-[calc(100%_-_108px)] top-[108px] bottom-[0px] left-[0px] bg-neutral-800 flex flex-col items-center justify-start p-12 box-border gap-[8px] text-left text-base text-neutral-800 font-body-regular">
      <NavBtn
        hugeIconinterfacesolidhom="/hugeiconinterfacesolidhome-04.svg"
        home="Home"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBorderRadius="unset"
        menuDesktopBackgroundColor="unset"
        hugeIconinterfacesolidhom="/hugeiconinterfacesolidsearch-02.svg"
        home="Search"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBorderRadius="unset"
        menuDesktopBackgroundColor="unset"
        hugeIconinterfacesolidhom="/hugeiconinterfaceoutlinehome-04.svg"
        home="Moves"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />

      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/hugeicontime-and-datesolidtimequarter-past@2x.png"
        home="History"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/heart-icons.svg"
        home="Liked videos"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/hugeiconfinance-and-paymentoutlinecard.svg"
        home="Payments"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/hugeiconfinance-and-paymentoutlinemoney-bagdollar.svg"
        home="Subscriptions"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/vector-3014.svg"
        home="Chat"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/hugeicondeviceoutlinenotification-01.svg"
        home="Notifications"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBackgroundColor="unset"
        menuDesktopBorderRadius="unset"
        hugeIconinterfacesolidhom="/hugeicondeviceoutlinesetting.svg"
        home="Settings"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />


      <NavBtn
        menuDesktopBorderRadius="12px"
        menuDesktopBackgroundColor="unset"
        hugeIconinterfacesolidhom="/hugeiconcommunicationoutlinecall.svg"
        home="Contact us"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBorderRadius="unset"
        menuDesktopBackgroundColor="unset"
        hugeIconinterfacesolidhom="/hugeiconinterfaceoutlineinformation.svg"
        home="About us"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <NavBtn
        menuDesktopBorderRadius="unset"
        menuDesktopBackgroundColor="unset"
        hugeIconinterfacesolidhom="/hugeiconinterfaceoutlinehelp.svg"
        home="FAQ"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
      <UpgradeBtn />

      <NavBtn
        menuDesktopBorderRadius="unset"
        menuDesktopBackgroundColor="unset"
         hugeIconinterfacesolidhom="/hugeiconarrowssolidin@2x.png"
        home="Log out"
        homeColor="#fff"
        showHugeIconinterfacesolidhom
        pro={false}
      />
    </nav>
  );
};

export default UserNav;
