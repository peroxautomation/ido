import SignUpButton from "./SignUpButton";
import SignUpMethodBTN from "./SignUpMethodBTN";

const SignUpMain = () => {
  return (
    <div className="absolute top-[calc(50%_-_436px)] left-[calc(50%_-_160px)] flex flex-col items-start justify-start gap-[16px] text-left text-base text-neutral-100 font-h2-regular">
      <div className="w-80 flex flex-row items-center justify-center py-0 px-2 box-border text-center text-21xl">
        <div className="relative leading-[48px]">Sign up</div>
      </div>
      <div className="w-80 flex flex-col items-start justify-start">
        <div className="self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-1">
          <div className="flex-1 relative leading-[24px]">Email</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconinterfacesolidinformation.svg"
          />
        </div>
        <input
          className="[border:none] [outline:none] font-h2-regular text-base bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center py-2.5 px-4 text-white-16"
          placeholder="Enter your email"
          type="text"
        />
        <div className="w-80 hidden flex-row items-center justify-center py-1 px-0 box-border text-sm text-neutral-600">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="w-80 flex flex-col items-start justify-start">
        <div className="self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-1">
          <div className="flex-1 relative leading-[24px]">Username</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconinterfacesolidinformation.svg"
          />
        </div>
        <input
          className="[border:none] [outline:none] font-h2-regular text-base bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center py-2.5 px-4 text-white-16"
          placeholder="Username"
          type="text"
        />
        <div className="w-80 hidden flex-row items-center justify-center py-1 px-0 box-border text-sm text-neutral-600">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="w-80 flex flex-col items-start justify-start">
        <div className="self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-1">
          <div className="flex-1 relative leading-[24px]">Password</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconinterfacesolidinformation.svg"
          />
        </div>
        <div className="self-stretch rounded-xl bg-white-8 flex flex-row items-center justify-center py-2.5 px-4">
          <input
            className="[border:none] [outline:none] font-h2-regular text-base bg-[transparent] flex-1 flex flex-row items-center justify-start text-white-16"
            placeholder="Create password"
            type="text"
          />
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] w-6 relative h-6 overflow-hidden shrink-0 hidden">
            <img
              className="absolute h-[58.33%] w-[83.33%] top-[20.83%] right-[8.33%] bottom-[20.83%] left-[8.33%] max-w-full overflow-hidden max-h-full"
              alt=""
              src="/subtract.svg"
            />
          </button>
        </div>
        <div className="w-80 hidden flex-row items-center justify-center py-1 px-0 box-border text-sm text-neutral-600">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="w-80 flex flex-col items-start justify-start">
        <div className="self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-1">
          <div className="flex-1 relative leading-[24px]">Confirm password</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconinterfacesolidinformation.svg"
          />
        </div>
        <div className="self-stretch rounded-xl bg-white-8 flex flex-row items-center justify-center py-2.5 px-4">
          <input
            className="[border:none] [outline:none] font-h2-regular text-base bg-[transparent] flex-1 flex flex-row items-center justify-start text-white-16"
            placeholder="Confirm your password"
            type="text"
          />
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] w-6 relative h-6 overflow-hidden shrink-0 hidden">
            <img
              className="absolute h-[58.33%] w-[83.33%] top-[20.83%] right-[8.33%] bottom-[20.83%] left-[8.33%] max-w-full overflow-hidden max-h-full"
              alt=""
              src="/subtract.svg"
            />
          </button>
        </div>
        <div className="w-80 hidden flex-row items-center justify-center py-1 px-0 box-border text-sm text-neutral-600">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="flex flex-col items-start justify-start">
        <div className="w-80 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
          <div className="flex-1 relative leading-[24px]">Label</div>
        </div>
        <div className="w-80 rounded-xl bg-white-8 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconmultimedia-and-audiosolidmusic-01.svg"
          />
          <div className="flex-1 relative leading-[24px]">Birthday</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconinterfaceoutlinecalendar.svg"
          />
        </div>
        <div className="w-80 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="flex flex-col items-start justify-start">
        <div className="w-80 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
          <div className="flex-1 relative leading-[24px]">Label</div>
        </div>
        <div className="w-80 rounded-xl bg-white-8 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
            alt=""
            src="/hugeiconmultimedia-and-audiosolidmusic-01.svg"
          />
          <div className="flex-1 relative leading-[24px]">Gender</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconarrowssoliddirectiondown-01.svg"
          />
        </div>
        <div className="w-80 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <SignUpButton />
      <div className="w-80 flex flex-row items-center justify-center p-2 box-border text-center">
        <div className="relative leading-[24px] font-semibold">
          Or sign up by
        </div>
      </div>
      <div className="flex flex-col items-start justify-start gap-[16px] text-center text-neutral-200">
        <SignUpMethodBTN
          hugeIcondeviceoutlineuser="/google.svg"
          cTA="Continue with Google"
          cTADesktopTabletAlignSelf="unset"
          cTADesktopTabletWidth="320px"
        />
        <SignUpMethodBTN
          hugeIcondeviceoutlineuser="/apple.svg"
          cTA="Continue with Apple"
          cTADesktopTabletAlignSelf="unset"
          cTADesktopTabletWidth="320px"
        />
        <SignUpMethodBTN
          hugeIcondeviceoutlineuser="/facebook.svg"
          cTA="Continue with Facebook"
          cTADesktopTabletAlignSelf="unset"
          cTADesktopTabletWidth="320px"
        />
        <div className="w-80 flex flex-row items-center justify-center py-2 px-0 box-border gap-[8px]">
          <div className="relative leading-[24px] font-semibold">
            Already have an account?
          </div>
          <a className="[text-decoration:none] relative leading-[24px] font-semibold text-primary-500">
            Log in
          </a>
        </div>
      </div>
    </div>
  );
};

export default SignUpMain;
