const DropdownGenre = () => {
  return (
    <div className={"absolute top-[148px] left-[calc(50%_-_408px)] flex flex-row items-start justify-start gap-[24px] text-left text-base text-neutral-100 font-body-semibold"}>
      <div className="w-40 flex flex-col items-start justify-start">
        <div className="w-40 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
          <div className="flex-1 relative leading-[24px]">Label</div>
        </div>
        <div className="w-40 rounded-xl bg-white-8 h-11 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
          <div className="flex-1 relative leading-[24px]">Genre</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconarrowssoliddirectiondown-01.svg"
          />
        </div>
        <div className="w-40 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="w-40 flex flex-col items-start justify-start">
        <div className="w-40 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
          <div className="flex-1 relative leading-[24px]">Label</div>
        </div>
        <div className="w-40 rounded-xl bg-white-8 h-11 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
          <div className="flex-1 relative leading-[24px]">Country</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconarrowssoliddirectiondown-01.svg"
          />
        </div>
        <div className="w-40 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="w-40 flex flex-col items-start justify-start">
        <div className="w-40 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
          <div className="flex-1 relative leading-[24px]">Label</div>
        </div>
        <div className="w-40 rounded-xl bg-white-8 h-11 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
          <div className="flex-1 relative leading-[24px]">Year</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconarrowssoliddirectiondown-01.svg"
          />
        </div>
        <div className="w-40 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <div className="w-40 flex flex-col items-start justify-start">
        <div className="w-40 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
          <div className="flex-1 relative leading-[24px]">Label</div>
        </div>
        <div className="w-40 rounded-xl bg-white-8 h-11 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
          <div className="flex-1 relative leading-[24px]">Rating</div>
          <img
            className="w-6 relative h-6 overflow-hidden shrink-0"
            alt=""
            src="/hugeiconarrowssoliddirectiondown-01.svg"
          />
        </div>
        <div className="w-40 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
          <div className="flex-1 relative leading-[20px]">Helper text</div>
        </div>
      </div>
      <button className="cursor-pointer [border:none] py-2.5 px-2 bg-primary-500 w-[340px] rounded-xl flex flex-row items-center justify-center box-border gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
          alt=""
          src="/hugeiconinterfacesolidplus1.svg"
        />
        <div className="relative text-base leading-[24px] font-semibold font-body-semibold text-neutral-100 text-center">
          Apply
        </div>
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
          alt=""
          src="/hugeiconinterfacesolidplus1.svg"
        />
      </button>
    </div>
  );
};
export default DropdownGenre;
