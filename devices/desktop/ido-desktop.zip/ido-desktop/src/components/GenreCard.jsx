import { useMemo } from "react";

const GenreCard = ({ cardLeft, genreName, genreNameLeft }) => {
  const cardStyle = useMemo(() => {
    return {
      left: cardLeft,
    };
  }, [cardLeft]);

  const genreNameStyle = useMemo(() => {
    return {
      left: genreNameLeft,
    };
  }, [genreNameLeft]);

  return (
    <div
      className="absolute top-[0px] left-[0px] rounded-2xl w-[180px] h-[180px] overflow-hidden bg-[url('/card1@3x.png')] bg-cover bg-no-repeat bg-[top] text-center text-base text-neutral-100 font-button-2-semibold"
      style={cardStyle}
    >
      <div className="absolute w-full right-[0px] bottom-[0px] left-[0px] rounded-t-none rounded-b-2xl [background:linear-gradient(180deg,_rgba(0,_0,_0,_0),_rgba(0,_0,_0,_0.8))] h-9" />
      <div
        className="absolute bottom-[7px] left-[34px] leading-[24px]"
        style={genreNameStyle}
      >
        {genreName}
      </div>
    </div>
  );
};

export default GenreCard;