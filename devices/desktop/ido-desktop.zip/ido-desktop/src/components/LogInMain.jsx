import SocialButtons from "./SocialButtons";

const LogInMain = () => {
  return (
    <div className="absolute w-[calc(100%_-_1120px)] top-[calc(50%_-_309px)] right-[560px] left-[560px] flex flex-col items-start justify-start gap-[16px] text-center text-base text-white font-button-2-semibold">
      <div className="self-stretch flex flex-row items-center justify-center py-0 px-2 text-21xl">
        <div className="relative leading-[48px]">Log in</div>
      </div>
      <div className="self-stretch flex flex-col items-start justify-start text-left">
        <div className="self-stretch flex flex-col items-start justify-start gap-[19px]">
          <div className="self-stretch flex flex-col items-start justify-start">
            <div className="self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-1">
              <div className="flex-1 relative leading-[24px]">Email</div>
              <img
                className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
                alt=""
                src="/hugeiconinterfacesolidinformation.svg"
              />
            </div>
            <input
              className="[border:none] [outline:none] font-button-2-semibold text-base bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center py-2.5 px-4 text-white"
              placeholder="Enter your email"
              type="text"
            />
            <div className="w-80 hidden flex-row items-center justify-center py-1 px-0 box-border text-sm text-neutral-600">
              <div className="flex-1 relative leading-[20px]">Helper text</div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start">
            <div className="self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-1">
              <div className="flex-1 relative leading-[24px]">Password</div>
              <img
                className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
                alt=""
                src="/hugeiconinterfacesolidinformation.svg"
              />
            </div>
            <input
              className="[border:none] [outline:none] font-button-2-semibold text-base bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-between py-2.5 px-4 text-white"
              placeholder="Enter your password"
              type="text"
            />
            <div className="w-80 hidden flex-row items-center justify-center py-1 px-0 box-border text-sm text-neutral-600">
              <div className="flex-1 relative leading-[20px]">Helper text</div>
            </div>
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-end py-2 px-0 gap-[145px]">
          <div className="w-[266px] relative leading-[24px] font-semibold hidden">
            Trending now
          </div>
          <a className="[text-decoration:none] relative leading-[24px] font-semibold text-[inherit] text-right">
            Forgot password
          </a>
        </div>
      </div>
      <button className="cursor-pointer [border:none] py-2.5 px-2 bg-primary-500 self-stretch rounded-xl flex flex-row items-center justify-center gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
          alt=""
          src="/hugeiconinterfacesolidplus.svg"
        />
        <div className="relative text-base leading-[24px] font-semibold font-button-2-semibold text-white text-center">
          Login
        </div>
      </button>
      <div className="self-stretch flex flex-row items-center justify-center p-2">
        <div className="flex-1 relative leading-[24px] font-semibold">
          Or log in by
        </div>
      </div>
      <SocialButtons />
      <div className="self-stretch flex flex-row items-center justify-center py-2 px-0 gap-[8px] text-neutral-200">
        <div className="relative leading-[24px] font-semibold">{`Don’t have an account? `}</div>
        <a className="[text-decoration:none] relative leading-[24px] font-semibold text-primary-500">
          Sign up
        </a>
      </div>
    </div>
  );
};

export default LogInMain;
