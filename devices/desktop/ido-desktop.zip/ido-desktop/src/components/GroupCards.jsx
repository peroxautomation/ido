import Card from "./Card";

const GroupCards = () => {
  return (
    <div className="absolute w-[calc(100%_-_360px)] top-[264px] right-[48px] left-[312px] grid grid-cols-4 gap-y-7 gap-x-4  text-center text-base text-neutral-100 font-sf-pro-text">
      <Card/>
      <Card />
      <Card />
      <Card />
      <Card/>
      <Card />
      <Card />
      <Card />
    </div>
  );
};

export default GroupCards;
