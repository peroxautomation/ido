const Dropdown = ({ dropdown }) => {
  return (
    <div className="flex flex-col items-start justify-start text-left text-base text-neutral-100 font-h2-regular">
      <div className="w-80 hidden flex-row items-start justify-start pt-0 px-0 pb-1 box-border">
        <div className="flex-1 relative leading-[24px]">Label</div>
      </div>
      <div className="w-80 rounded-xl bg-white-8 flex flex-row items-center justify-start py-2.5 px-4 box-border gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
          alt=""
          src="/hugeiconmultimedia-and-audiosolidmusic-01.svg"
        />
        <div className="flex-1 relative leading-[24px]">{dropdown}</div>
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0"
          alt=""
          src="/hugeiconarrowssoliddirectiondown-01.svg"
        />
      </div>
      <div className="w-80 hidden flex-row items-center justify-start py-1 px-0 box-border text-sm">
        <div className="flex-1 relative leading-[20px]">Helper text</div>
      </div>
    </div>
  );
};

export default Dropdown;
