const SignUpButton = () => {
  return (
    <button className="cursor-pointer [border:none] py-2.5 px-2 bg-primary-500 w-80 rounded-xl flex flex-row items-center justify-center box-border gap-[8px]">
      <img
        className="w-6 relative h-6 overflow-hidden shrink-0 hidden"
        alt=""
        src="/hugeiconinterfacesolidplus.svg"
      />
      <div className="relative text-base leading-[24px] font-semibold font-h2-regular text-neutral-100 text-center">
        Sign up
      </div>
    </button>
  );
};

export default SignUpButton;
