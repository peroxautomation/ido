const LOGO = () => {
  return (
    <div className="relative text-13xl leading-[40px] font-semibold font-body-regular text-neutral-100 text-center">
      LOGO
    </div>
  );
};

export default LOGO;
