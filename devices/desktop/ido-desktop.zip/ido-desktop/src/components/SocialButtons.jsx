const SocialButtons = () => {
  return (
    <div className="self-stretch flex flex-col items-start justify-start gap-[16px]">
      <button className="cursor-pointer [border:none] py-2.5 px-2 bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0"
          alt=""
          src="/google.svg"
        />
        <div className="relative text-base leading-[24px] font-semibold font-button-2-semibold text-white text-center">
          Continue with Google
        </div>
      </button>
      <button className="cursor-pointer [border:none] py-2.5 px-2 bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0"
          alt=""
          src="/apple.svg"
        />
        <div className="relative text-base leading-[24px] font-semibold font-button-2-semibold text-white text-center">
          Continue with Apple
        </div>
      </button>
      <button className="cursor-pointer [border:none] py-2.5 px-2 bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center gap-[8px]">
        <img
          className="w-6 relative h-6 overflow-hidden shrink-0"
          alt=""
          src="/facebook.svg"
        />
        <div className="relative text-base leading-[24px] font-semibold font-button-2-semibold text-white text-center">
          Continue with Facebook
        </div>
      </button>
    </div>
  );
};

export default SocialButtons;
