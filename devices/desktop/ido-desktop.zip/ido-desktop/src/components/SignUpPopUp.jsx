import SignUpMethodBTN from "./SignUpMethodBTN";

const SignUpPopUp = () => {
  return (
    <div>
      <div className="absolute w-[calc(100%_-_1024px)] top-[284px] right-[512px] left-[512px] rounded-3xl bg-neutral-800 flex flex-col items-end justify-start p-6 box-border gap-[16px] text-center text-base text-neutral-100 font-body-regular z-20">
        <button className="cursor-pointer [border:none] p-0 bg-[transparent] w-8 relative h-8 overflow-hidden shrink-0">
          <img
            className="absolute h-[41.56%] w-[41.56%] top-[29.06%] right-[29.37%] bottom-[29.37%] left-[29.06%] max-w-full overflow-hidden max-h-full"
            alt=""
            src="/remove.svg"
          />
        </button>
        <div className="self-stretch flex flex-col items-center justify-start py-0 px-6 gap-[32px] text-center text-5xl text-neutral-100 font-h2-regular">
          <div className="self-stretch relative leading-[32px]">Sign up to Ido</div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[16px]">
            <SignUpMethodBTN
              hugeIcondeviceoutlineuser="/hugeicondeviceoutlineuser.svg"
              cTA="Use Email / Username"
            />
            <SignUpMethodBTN
              hugeIcondeviceoutlineuser="/google.svg"
              cTA="Continue with Google"
              cTADesktopTabletAlignSelf="stretch"
              cTADesktopTabletWidth="unset"
            />
            <SignUpMethodBTN
              hugeIcondeviceoutlineuser="/apple.svg"
              cTA="Continue with Apple"
              cTADesktopTabletAlignSelf="stretch"
              cTADesktopTabletWidth="unset"
            />
            <SignUpMethodBTN
              hugeIcondeviceoutlineuser="/facebook.svg"
              cTA="Continue with Facebook"
              cTADesktopTabletAlignSelf="stretch"
              cTADesktopTabletWidth="unset"
            />
          </div>
          <div className="w-80 flex flex-row items-center justify-center py-2 px-0 box-border gap-[8px] text-base text-neutral-200">
            <div className="relative leading-[24px] font-semibold">{`Already have an account? `}</div>
            <a className="[text-decoration:none] relative leading-[24px] font-semibold text-primary-500">
              Log in
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPopUp;
