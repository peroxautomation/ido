import React from 'react'
import DropdownGenre from './DropdownGenre'
import GroupCards from './GroupCards'

const SearchMain = () => {
  return (
    <div>
      <DropdownGenre/>
      <GroupCards/>
    </div>
  )
}

export default SearchMain
