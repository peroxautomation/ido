import { useMemo } from "react";

const SignUpMethodBTN = ({
  hugeIcondeviceoutlineuser,
  cTA,
  cTADesktopTabletAlignSelf,
  cTADesktopTabletWidth,
}) => {
  const cTADesktopTabletStyle = useMemo(() => {
    return {
      alignSelf: cTADesktopTabletAlignSelf,
      width: cTADesktopTabletWidth,
    };
  }, [cTADesktopTabletAlignSelf, cTADesktopTabletWidth]);

  return (
    <button
      className="cursor-pointer [border:none] py-2.5 px-2 bg-white-8 self-stretch rounded-xl flex flex-row items-center justify-center gap-[8px]"
      style={cTADesktopTabletStyle}
    >
      <img
        className="w-6 relative h-6 overflow-hidden shrink-0"
        alt=""
        src={hugeIcondeviceoutlineuser}
      />
      <div className="relative text-base leading-[24px] font-semibold font-h2-regular text-neutral-100 text-center">
        {cTA}
      </div>
    </button>
  );
};

export default SignUpMethodBTN;
