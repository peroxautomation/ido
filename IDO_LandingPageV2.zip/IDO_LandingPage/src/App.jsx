import './App.css'
import Desktop from "./pages/Desktop"
import Tablet from "./pages/Tablet"
import Mobile from "./pages/Mobile"

function App() {
  return(
    <div>
      {/* <Desktop/> */}
      {/* <Tablet/> */}
      <Mobile/>
    </div>
  )
}

export default App
