const MFooterNav = () => {
  return (
    <div
      className={`absolute top-[216px] left-[calc(50%_-_175px)] w-[260px] h-[119px] text-left text-base text-neutral-100 font-button-2-regular`}
    >
      <div className="absolute top-[0px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">APPs</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
      <div className="absolute top-[35px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">API</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
      <div className="absolute top-[35px] left-[176px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">FAQ</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
      <div className="absolute top-[0px] left-[176px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Partnership</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
      <div className="absolute top-[65px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Adverts</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
      <div className="absolute top-[65px] left-[176px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Contact</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
      <div className="absolute top-[95px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Price</div>
        <img
          className="w-px absolute !m-[0] top-[24px] left-[0px] h-0 object-contain opacity-[0] z-[1]"
          alt=""
        />
      </div>
    </div>
  );
};

export default MFooterNav;
