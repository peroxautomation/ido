const TFooterNav = () => {
  return (
    <div
      className={`absolute top-[64px] left-[calc(50%_+_102px)] w-[262px] h-[119px] text-left text-base text-neutral-100 font-button-1-regular`}
    >
      <div className="absolute top-[0px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">APPs</div>
      </div>
      <div className="absolute top-[35px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">API</div>
      </div>
      <div className="absolute top-[35px] left-[178px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">FAQ</div>
      </div>
      <div className="absolute top-[0px] left-[178px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Partnership</div>
      </div>
      <div className="absolute top-[65px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Adverts</div>
      </div>
      <div className="absolute top-[65px] left-[178px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Contact</div>
      </div>
      <div className="absolute top-[95px] left-[0px] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] active:underline">Price</div>
      </div>
    </div>
  );
};

export default TFooterNav;
