const DFooterNav = () => {
  return (
    <div
      className={`absolute top-[81px] left-[calc(50%_-_127px)] w-[193px] h-[119px] text-left text-base text-neutral-100 font-body-semibold`}
    >
      <div className="absolute top-[0px] left-[calc(50%_-_96.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">APPs</div>
      </div>
      <div className="absolute top-[0px] left-[calc(50%_+_12.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">Partnership</div>

      </div>
      <div className="absolute top-[35px] left-[calc(50%_-_96.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">API</div>

      </div>
      <div className="absolute top-[35px] left-[calc(50%_+_12.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">FAQ</div>

      </div>
      <div className="absolute top-[65px] left-[calc(50%_-_96.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">Adverts</div>

      </div>
      <div className="absolute top-[65px] left-[calc(50%_+_12.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">Contact</div>

      </div>
      <div className="absolute top-[95px] left-[calc(50%_-_96.5px)] flex flex-col items-center justify-start">
        <div className="relative leading-[24px] z-[0] hover:underline cursor-pointer">Price</div>
      </div>
    </div>
  );
};

export default DFooterNav;
